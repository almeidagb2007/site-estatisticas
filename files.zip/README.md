# Site de estatísticas do futebol brasileiro

- `index.html`: lista dos clubes
- `<clube>.html`: página de cada clube
- `dados-<clube>.json`: dados de cada clube

Atualizar depois de um jogo: envie o `dados-<clube>.json` novo com o mesmo nome (Add file → Upload files) e faça o commit.
Clube novo: envie `<clube>.html` e `dados-<clube>.json` e preencha o `url` do clube na lista `CLUBES` do `index.html` com `<clube>.html`.
Abrir os arquivos direto do computador não carrega os dados; use o site publicado.
